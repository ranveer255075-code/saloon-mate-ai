"""SalonMate AI backend package."""
